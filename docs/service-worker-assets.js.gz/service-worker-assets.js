self.assetsManifest = {
  "version": "Bg1iLww4",
  "assets": [
    {
      "hash": "sha256-9NOfRyWfHEVhZcIgwc/DG6x0RpfedGZU2l4JLSPdN3k=",
      "url": "LilytechLab.GuitarStringTensionCalculator.styles.css"
    },
    {
      "hash": "sha256-3FM/mjas9rQiq2CY+FQPy1Pe1iCLSx/qZltQxK4dcuQ=",
      "url": "_content/MudBlazor/MudBlazor.min.css"
    },
    {
      "hash": "sha256-Qf9/gSPxTxchB08Wi5WXxjPqw2IQvnyVUW27s7cwoUo=",
      "url": "_content/MudBlazor/MudBlazor.min.js"
    },
    {
      "hash": "sha256-bPLruHUtlhGMT16JTFClVnhzxt3P+ljgx3f/xnYZ5p8=",
      "url": "_framework/LilytechLab.GuitarStringTensionCalculator.kcl2dmzngl.wasm"
    },
    {
      "hash": "sha256-+HDwVKBM7lv/0/b6jJg9fuV6M5Cc/w9V/+X3ps1SHxs=",
      "url": "_framework/MemoryPack.Core.czx0bu0vck.wasm"
    },
    {
      "hash": "sha256-4qCjCkeMkrC39fhhzGK6jZVM+CSQXhBgirZfr1DM/6I=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.yv2qi7o6jg.wasm"
    },
    {
      "hash": "sha256-HO1dBcm8jewRNZxl1b1Zmav2vcUT2uV3jWFfkgJR0FQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.o1meee4m6r.wasm"
    },
    {
      "hash": "sha256-Qa06ZEZYNy5H3IcJKiit0xORvL00i0J6oaInh6FvuJs=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.xos43cv7si.wasm"
    },
    {
      "hash": "sha256-/PDHimwRScKUsksCyRVmT9hre7XAkUqq2mbmQWzFJeU=",
      "url": "_framework/Microsoft.AspNetCore.Components.ojs6dj6i10.wasm"
    },
    {
      "hash": "sha256-3ADlF4CLU1Q+dQbj0MnPVnEJPiA4q4Jv5xxmiGEvBks=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.85u9862gz3.wasm"
    },
    {
      "hash": "sha256-kKMubKJ3c2lATxpoAuoDqMjzQ+a0M6Ym35pK74cMK2o=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.0cm6d8ej68.wasm"
    },
    {
      "hash": "sha256-fN4AyqImDQ+h3H7tFeF4ZSkjIHJ7qWgbKL217x6P53s=",
      "url": "_framework/Microsoft.Extensions.Configuration.cyz6aj3end.wasm"
    },
    {
      "hash": "sha256-VerCbY+gtR4pfthf2m0i5NHYHdzae5bPti0u8jro/mE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.pzhxlzbjs7.wasm"
    },
    {
      "hash": "sha256-Sgs1bgmGaF2mv6rWcaihc+x48ZQQAidfzYwZvYX5WJk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.uum8fsrbn4.wasm"
    },
    {
      "hash": "sha256-TxsQmQlsqu3myAIuVFT/WRwOu2n8urJiNGHHzkN2eYI=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.pab6euid13.wasm"
    },
    {
      "hash": "sha256-6UgMJoVZBfDdfzYR0aKVK6BWArxpXC1qiQDDjiXw/L4=",
      "url": "_framework/Microsoft.Extensions.Localization.bvn14pws96.wasm"
    },
    {
      "hash": "sha256-uoBWN1EXPb2NuqCrRtfEd0Y1a2QMXfyhRaIKp+eQ/So=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.25xesdv4z6.wasm"
    },
    {
      "hash": "sha256-I/euMiwOKn2U2Y1vqcUjYWEG/7zWmvDiTlHAoPLRHQ0=",
      "url": "_framework/Microsoft.Extensions.Logging.p9svcbtg1a.wasm"
    },
    {
      "hash": "sha256-iCJ7MgEDmi8gJJ4kr+vCM0UW+W51Th0XAwRG1vPU9Ak=",
      "url": "_framework/Microsoft.Extensions.Options.sv9qmqvsmm.wasm"
    },
    {
      "hash": "sha256-WXYpl64HUqc9+prJOz6dOEVvB8PFJhTdfqUMB3ZGRGA=",
      "url": "_framework/Microsoft.Extensions.Primitives.5pxr7nzxwe.wasm"
    },
    {
      "hash": "sha256-mpyjzA6YBuV9Qx5BUC8YbXP9YjZlM+k7YTVawzXJFgk=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.imfqvv3x5h.wasm"
    },
    {
      "hash": "sha256-eoY1xfVgWFPBStmS/9YW1VtHmZDVUN/Zwr4tEbhI0RQ=",
      "url": "_framework/Microsoft.JSInterop.ea103878px.wasm"
    },
    {
      "hash": "sha256-Z/RKva6LB7nj2d4u142nEssRrGQU6ywQqCqq/UinXSc=",
      "url": "_framework/MudBlazor.x2vxgos7ym.wasm"
    },
    {
      "hash": "sha256-G9PmDPnbAHm13DUXwFQTkWcsGepgSxHijbLNYMKhYTM=",
      "url": "_framework/System.Collections.5ocv7hhyaf.wasm"
    },
    {
      "hash": "sha256-5MtQVDRlaVZfraFadWN0U1gESRP7/HGlaSYcUugnx8U=",
      "url": "_framework/System.Collections.Concurrent.wt3qemp3i2.wasm"
    },
    {
      "hash": "sha256-CJfnhnoRRKfaMVp2Qxsm5iqZZh4hzm00OC++DVQ6iWQ=",
      "url": "_framework/System.Collections.Immutable.g6tptbwzl8.wasm"
    },
    {
      "hash": "sha256-/TUgJRG3EZB5Bcfo9BEFJ61DIJLAJRTXeLYB1vnMd1Q=",
      "url": "_framework/System.ComponentModel.5y3o4qq5pj.wasm"
    },
    {
      "hash": "sha256-OEUiONvTvRl0zXaRpOxe8N1bZm9G8n1a8O1MU0CuiIs=",
      "url": "_framework/System.ComponentModel.Annotations.c3oteuai4j.wasm"
    },
    {
      "hash": "sha256-kBzp10NYPlN9m9Lu20Aqmqij6KZcgw2iYgcyjE1Oj5M=",
      "url": "_framework/System.ComponentModel.Primitives.gw0gkk5sib.wasm"
    },
    {
      "hash": "sha256-fe53dkPGbPTDsVexItWDMsFKY7AVXufPswNaBhAPX2w=",
      "url": "_framework/System.ComponentModel.TypeConverter.zgmbvnl9ci.wasm"
    },
    {
      "hash": "sha256-OLm71vFejrfS7tuHwbQIrbPJJFFvqFC1eM7SgYnxTfA=",
      "url": "_framework/System.Console.gi7zmwq5sa.wasm"
    },
    {
      "hash": "sha256-1YO3z/gMfBPD5h+5v2920aG/dfV0nUx87gSNPx1WSUM=",
      "url": "_framework/System.IO.Compression.Brotli.v3mha2y9ar.wasm"
    },
    {
      "hash": "sha256-zefaR+Cp1p+h4jO+3NWRNUvulKCgGwqkqhyd4snGJBM=",
      "url": "_framework/System.IO.Compression.nb51fu6h0u.wasm"
    },
    {
      "hash": "sha256-jU8ES0WWSBVZyMOlwLBRvFARHEGQrU/jD9cEIk46CRk=",
      "url": "_framework/System.IO.Pipelines.1j2jw33yd5.wasm"
    },
    {
      "hash": "sha256-T5aIvblpPkrCyPo6wW7xNx403EZ6q05eSBUN4aVeBbA=",
      "url": "_framework/System.Linq.Expressions.lzvj18kh7x.wasm"
    },
    {
      "hash": "sha256-J0kX8CL0oA+hMWPYPWBktsZN105kWTG3dmnD1tB+vIA=",
      "url": "_framework/System.Linq.t78hnztf00.wasm"
    },
    {
      "hash": "sha256-aNg2g8iXYsXfbdNFxrR28+imQqR9M5YZHCwaLVzAYpg=",
      "url": "_framework/System.Memory.gicxa4lpmo.wasm"
    },
    {
      "hash": "sha256-AUh9H4KMFMgWv0ROj41gfS07588GWmmrsXuyfoooljc=",
      "url": "_framework/System.Net.Http.xgu7qeey5v.wasm"
    },
    {
      "hash": "sha256-ATD97tYcgeYU6qhLjcFpeIbpkzSMNEqYgBaQAzNMgCQ=",
      "url": "_framework/System.Net.Primitives.xosvhvwc8p.wasm"
    },
    {
      "hash": "sha256-S90Zu1rLHgPtvoR4/dECYq/giFjAbmKcJ+8aY01L7r0=",
      "url": "_framework/System.Numerics.Vectors.du7w3gl7ow.wasm"
    },
    {
      "hash": "sha256-+sWaTMRUlWKHw1ycOrY70Y7htfJEsJtKk2ji7+P1dqo=",
      "url": "_framework/System.ObjectModel.ipfyidt5t7.wasm"
    },
    {
      "hash": "sha256-jwCponSa5KxXyWolz/gkDiDwyaQHnO+Fg24h31F2f6Y=",
      "url": "_framework/System.Private.CoreLib.jncmvuaffd.wasm"
    },
    {
      "hash": "sha256-bq29+PtqFVdf3lTxJJScrgGz+J7qQ96TLl5M+UorNzk=",
      "url": "_framework/System.Private.Uri.e8835ztk9b.wasm"
    },
    {
      "hash": "sha256-04wcjfWnVIHxF3O1Vag5Wk/gAkpeirlXt1MF9qX2TzA=",
      "url": "_framework/System.Runtime.177v1b94ax.wasm"
    },
    {
      "hash": "sha256-5Gru8lhVTGY7XS1KKVRZjDFARt3p1nsfa1Tj2CPdRsI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.cqbusmqy15.wasm"
    },
    {
      "hash": "sha256-LfM6BypmGux3PI4QlIFNgVImNiJP2cT2bRxIdmr+NEc=",
      "url": "_framework/System.Runtime.InteropServices.t4gipi9sfm.wasm"
    },
    {
      "hash": "sha256-UNQjz14xvj+E6kbEUxxMPU/CYM1t3YaLZye4hL4OLz0=",
      "url": "_framework/System.Runtime.Intrinsics.sd07a9u9f1.wasm"
    },
    {
      "hash": "sha256-i4VvjkF9ayLkOnVMNbUmHr39ZBKhPpHZn2kq4Ze7CtI=",
      "url": "_framework/System.Runtime.Numerics.9zgiozhfmj.wasm"
    },
    {
      "hash": "sha256-nowVPzdhrYNVwBj7BFC6KceUhojJ5Gz2vZGxT0qFoSA=",
      "url": "_framework/System.Text.Encodings.Web.e8bnsydrha.wasm"
    },
    {
      "hash": "sha256-q30Uvfz0EWmG4sYRd35vxt1dwVGDMMvGV2q3tjVI2nE=",
      "url": "_framework/System.Text.Json.da2j8ymzdr.wasm"
    },
    {
      "hash": "sha256-HNVatHpcpSoVEw24rTPfvxjnYUTeABrJm0FSQV49Bl0=",
      "url": "_framework/System.Text.RegularExpressions.89dcfqzf8o.wasm"
    },
    {
      "hash": "sha256-8TOdx+WTSrBAkPVcYh/dHgxZeRNAfj3bK1p4ESYA1bo=",
      "url": "_framework/System.Threading.92ez24v1xd.wasm"
    },
    {
      "hash": "sha256-hkGLo/MuT/FJ0Xf4XUL0D2VA4dZV532GHNB1JicxLko=",
      "url": "_framework/System.m0fu6d0eya.wasm"
    },
    {
      "hash": "sha256-O+CfqUnNTQwMd2qCKdEPQyGm+Xk0ioJpZny9d9bHCto=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-gD2XMSIt+vtDFirTg+LVASuuDVoOW3S7fY2a27Ou3Vs=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-RtuwNrUOdAJ5A4aS4ZmceO4ySriaYqTdC7X++6yd9lM=",
      "url": "_framework/dotnet.native.21mns4qp4i.wasm"
    },
    {
      "hash": "sha256-oS7IRiQoVt9ThQ7Y2UM3XoeY0JqPD02cg9IvRdufn2w=",
      "url": "_framework/dotnet.native.9ih887ebfz.js"
    },
    {
      "hash": "sha256-oBRKHAqZUsvCRnCzkQfB7zc45cpKLNq2NKyrG10IKx8=",
      "url": "_framework/dotnet.runtime.st3wwc8rqy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-4fcQynvKUZbeSqKXa+2ZKbXi04DpqGH+eFeQJtqsZk0=",
      "url": "_framework/ja/LilytechLab.GuitarStringTensionCalculator.resources.3fgk0izj3o.wasm"
    },
    {
      "hash": "sha256-vGbjgqEqv4y3q5OB8W2R9LthkuF8mQfHFeNdKSReSmU=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-+w9CYnrsiKW1F9KMvq/L4CpPHe416hPbvglqUOy5k38=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-LIUUXlXIRbfPD9nqxjUngnHw43NKneW0KiU/YauQ8tk=",
      "url": "helper.js"
    },
    {
      "hash": "sha256-a8uGRW4l4/q32e78tKLFFBdARZouRBD/PhISGH6QTo8=",
      "url": "helper.js.map"
    },
    {
      "hash": "sha256-9irbTIDS8bHTPHwbzJ7w41DVb6ylrrZatLX0zkrPaGg=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-zayXo/XMjth7XCX3PXke/InMa2NOUHu4BoEwPezPmbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-55amfHvj2UjiJ7mslGv2oycWVBclKT6xB2tLzee0hyY=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-yRnLaK5u6HrbYgM9WpjI+gjc8D8lHGzm5CyK1YWkcAw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-o0U5Sti6e4oyV/KLdis2sWh1lmv4jYHy36o5/YK2QEM=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-SfllRYIcY+8Y3YGogpq1+c3PdKJF8CzpkxH8NZfbY5c=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-1lBYhuydh5oGPlYsMm2O/JEFubzcPVcGJFnTfj/9rKU=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-UEsNOeSMvxsBkkann3AFqmyVxZVlOhYfVAS5JtS2nvA=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-jmWHRhes4frZUmfg7SKXe166pDATfNBIP+0xRa5/NQM=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-Tqa/MpCnccwpStxfBierN2dLK50nlzaW1MUIJtJ+XdE=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-gonP394iPL+gDmnoOYoCpWnBeDBw4NNuGea6MEh6GZ4=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-D3cnvcSag+Yl0o8EF4DKbojUg4dexslQKbaqyzNJGcA=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-CZXglGygsl9VdTo4U+M4s57+n2PGVWe5L3F4QVXwca0=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-+wWTqq+o7o4B4fV4KztFtYTsguqq5ZgngVcs7AyCjzw=",
      "url": "resources/yt_icon_white_digital.png"
    },
    {
      "hash": "sha256-HJAEfsbf2uZ6skshpn1ODCnPTGB3+VyG0+XPFUp6AdM=",
      "url": "resources/りりらぼロゴ_120px.png"
    }
  ]
};
